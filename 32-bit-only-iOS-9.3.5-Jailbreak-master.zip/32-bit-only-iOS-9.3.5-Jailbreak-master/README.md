# 32-bit-only-iOS-9.3.5-Jailbreak

This is a 32 bit only Semi-Tethered Jailbreak for iOS 9.3.5.

EXPLOIT IS NOT YET INCLUDED, SO THE UI IS THE ONLY PART THAT'S WORKING RIGHT NOW!!

Already supported (Exploit): iPhone 4S, iPad 2, iPad 3.

Planned Support (Exploit): iPhone 5, iPhone 5C, iPod Touch 5G, iPad 4, iPad Mini. 

Please do not open an issue for any silly reasons, it will just be closed right away!

Please do not steal code! This is for all of us to work on!

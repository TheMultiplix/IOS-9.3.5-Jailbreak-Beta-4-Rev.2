//
//  _2_bit_only_iOS_9_3_5_JailbreakTests.m
//  32 bit only iOS 9.3.5 JailbreakTests
//
//  Created by Brandon Withall on 2017-02-14.
//  Copyright © 2017 Brando1235703. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _2_bit_only_iOS_9_3_5_JailbreakTests : XCTestCase

@end

@implementation _2_bit_only_iOS_9_3_5_JailbreakTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
